# 视觉元素与模板使用说明

## 已确认的使用要求

mushenzhen 允许视觉元素和模板用于商业用途。使用时**必须提到 mushenzhen**，不能仅使用素材却省略来源名称。

适用范围：品牌方提供的视觉元素与模板。Logo 按品牌使用指南使用；字体、照片和第三方素材按其各自授权处理；工具代码许可另行确定。

## 署名写法与位置建议

可直接使用：

- 视觉素材来源：mushenzhen
- 使用 mushenzhen 视觉元素制作
- Visual assets by mushenzhen
- Adapted using mushenzhen visual assets

署名应让观看作品的人能够找到。海报可放在页脚，社交媒体作品可在随图文案中注明，网页可在作品说明或 credits 中注明。若单独转发图片，建议把来源一同保留。

“必须提到 mushenzhen”是已确认要求；上述具体写法与位置是便于执行的建议，不强制额外宣传文案或固定署名字号。不得因使用素材而暗示自己获得了 mushenzhen 官方合作或背书。

本文件记录品牌方确认的使用政策；尚未选择标准公开许可证，不应自行标为 MIT、CC0 或其他许可。活动日历模板现已收录于 templates/calendar；其第三方照片与字体按目录内的资产及许可说明处理。

City Maker 人物海报模板位于 templates/city-maker；字体按随包 SIL OFL 许可，人物照片和肖像不自动属于品牌视觉授权范围。该模板未包含网上人物测试照片。

Future, Unboxed 产品海报位于 templates/future-unboxed；附用户提供的默认眼镜展示图，照片不自动适用品牌视觉授权。网上品牌测试照片不随库分发，来源及下载说明见该模板。

明日出厂海报模板位于 templates/tomorrow-factory，附用户设计稿提取的工厂照片及两套配色。照片不自动适用品牌视觉素材授权；字体许可随包附带。

未来实验活动海报位于 templates/future-lab。默认照片由用户参考图经AI清理叠字和Logo得到，作为版式演示，不代表未修改摄影原片；正式制作优先替换独立原图。
